//
//  Constant.swift
//  GrubberDemo
//
//  Created by Puneet Shah on 25/12/20.
//  Copyright © 2020 Puneet Shah. All rights reserved.
//

import UIKit

class Constant: NSObject {
        
}

