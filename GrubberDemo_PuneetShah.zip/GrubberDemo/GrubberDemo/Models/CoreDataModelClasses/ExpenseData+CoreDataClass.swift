//
//  ExpenseData+CoreDataClass.swift
//  GrubberDemo
//
//  Created by Puneet Shah on 25/12/20.
//  Copyright © 2020 Puneet Shah. All rights reserved.
//
//

import Foundation
import CoreData

@objc(ExpenseData)
public class ExpenseData: NSManagedObject {

}
